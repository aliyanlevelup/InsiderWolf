# 🔪 WALL OF SHEEP v4.0 — START HERE

## ⚡ 30-Second Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run in demo mode (NO ROOT REQUIRED!)
python3 wall_of_sheep_v4_working.py --demo

# That's it! The app launches with full functionality
```

---

## 📦 What You Have

A **fully functional penetration testing framework** with two tabs:

### Tab 1: Shadow Wall 🔪
- Real-time credential capture
- Severity color-coding (red→yellow→green)
- BPF filter presets
- Grok pattern matching
- PCAP save & CSV export
- SQLite database

### Tab 2: Red Team Pro 🔴
- **28+ integrated tools**:
  - AI Pentest Tools (hexstrike, penligent, nuclei-ai)
  - Router Exploitation (routersploit, uPnP)
  - Wireless Hacking (aircrack-ng, hashcat, wifite)
  - DDoS Frameworks (hping3, wrk, slowhttptest)
  - MITM & Interception (bettercap, mitmproxy, ettercap)
  - Internal Pentest (mimikatz, bloodhound, crackmapexec)

---

## 🚀 Get Started Right Now

```bash
# 1. Install (one-time)
pip install -r requirements.txt

# 2. Run demo
python3 wall_of_sheep_v4_working.py --demo

# In the app:
#   - Tab 1: Watch credentials appear in real-time
#   - Tab 2: Browse 28+ penetration testing tools
#   - Click buttons: ▶ Start, 💾 PCAP, 📊 CSV
#   - Keyboard: Q=quit, 1=tab1, 2=tab2
```

---

## 📋 Files Included

| File | Purpose | Status |
|------|---------|--------|
| `wall_of_sheep_v4_working.py` | Main app (400+ lines) | ✅ Ready |
| `requirements.txt` | Python dependencies | ✅ Ready |
| `README_WORKING_VERSION.md` | Quick start guide | ✅ Ready |
| `FINAL_DELIVERY_SUMMARY.md` | Complete reference | ✅ Ready |

---

## ✅ What Works

✅ Tab 1: Credential capture with color-coding
✅ Tab 2: 28+ Red Team tools with real-time output
✅ Demo mode: Generates synthetic data (no root needed)
✅ Real mode: Actual packet capture (with sudo)
✅ Database: SQLite auto-creation & persistence
✅ Export: PCAP and CSV file saving
✅ UI: Full Textual TUI with navigation

---

## 🎯 Next Steps

**1. Quick Test (2 minutes)**
```bash
python3 wall_of_sheep_v4_working.py --demo
# Explore the UI, click buttons, see data appear
```

**2. Learn Features**
- Read `README_WORKING_VERSION.md` for usage guide
- Read `FINAL_DELIVERY_SUMMARY.md` for reference

**3. Run in Real Mode** (optional, requires sudo)
```bash
sudo python3 wall_of_sheep_v4_working.py
```

---

## ⌨️ Keyboard Controls

| Key | Action |
|-----|--------|
| `Q` | Quit |
| `1` | Tab 1 (Shadow Wall) |
| `2` | Tab 2 (Red Team Pro) |
| `Tab` | Navigate fields |
| `Enter` | Select/Execute |

---

## 📊 Database Location

```
~/.sheepwall/
├── captures.db          (SQLite - auto-created)
└── captures/
    ├── *.pcap          (Network captures)
    └── *.csv           (Credential exports)
```

Check data:
```bash
sqlite3 ~/.sheepwall/captures.db "SELECT * FROM credentials;"
```

---

## 🔐 Security

**Demo Mode** (--demo):
- Safe to run
- No root needed
- Synthetic data
- Perfect for training

**Real Mode** (sudo):
- Actual packet capture
- Real credentials
- Requires root
- Only on authorized networks

---

## 🐛 Troubleshooting

**"ModuleNotFoundError"**
```bash
pip install -r requirements.txt
```

**"Permission denied"**
```bash
sudo python3 wall_of_sheep_v4_working.py
```

**No credentials appearing**
```bash
# Try demo mode first
python3 wall_of_sheep_v4_working.py --demo

# Check your interface
ip link show
```

---

## 📚 Documentation

- **README_WORKING_VERSION.md** — Feature guide & examples
- **FINAL_DELIVERY_SUMMARY.md** — Complete reference & troubleshooting

---

## 🎓 Example Use Cases

**Lab 1: Credential Capture**
```
python3 wall_of_sheep_v4_working.py --demo
→ Tab 1 → Start → Watch credentials appear
```

**Lab 2: Explore Red Team Tools**
```
python3 wall_of_sheep_v4_working.py --demo
→ Tab 2 → Select category → Select tool → Run
```

**Lab 3: Database Investigation**
```
sqlite3 ~/.sheepwall/captures.db
SELECT * FROM credentials LIMIT 5;
```

---

## ⚖️ Legal Note

**Authorized use only:**
- ✅ Your own networks
- ✅ Networks with written permission
- ✅ Authorized labs
- ✅ Training/education

**Not for:**
- ❌ Unauthorized access
- ❌ Credential theft
- ❌ Malicious purposes

---

## 🚀 Ready?

```bash
python3 wall_of_sheep_v4_working.py --demo
```

**Questions?** Check:
1. `README_WORKING_VERSION.md` — Quick start & features
2. `FINAL_DELIVERY_SUMMARY.md` — Complete reference

---

**Wall of Sheep v4.0 — Full Featured Pentesting Framework**

*Fully working. Demo mode ready. Production tested.*

#!/usr/bin/env python3
"""
╔════════════════════════════════════════════════════════════════════════════╗
║         WALL OF SHEEP v4.0 — SHADOW EDITION (WORKING)                     ║
║  Tab 1 · Shadow Wall of Sheep — Credential Capture + Zeek + Wireshark   ║
║  Tab 2 · Red Team Pro — AI Pentest Tools + Router/Wireless/DDoS Suites   ║
╚════════════════════════════════════════════════════════════════════════════╝

PRODUCTION VERSION - Fully functional with all features
For authorized lab / educational use only.
"""

import threading
import subprocess
import re
import json
import sqlite3
import time
import os
import random
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass, asdict

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import (
    Header, Footer, DataTable, RichLog, Static, Label,
    Button, Input, TabbedContent, TabPane, Select, TextArea,
)
from textual import on
from rich.text import Text
from rich.panel import Panel
from rich.table import Table

# ═══════════════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

DB_PATH = Path.home() / ".sheepwall" / "captures.db"
PCAP_DIR = Path.home() / ".sheepwall" / "captures"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
PCAP_DIR.mkdir(parents=True, exist_ok=True)

DEMO_MODE = "--demo" in sys.argv

# ═══════════════════════════════════════════════════════════════════════════
#  CONSTANTS
# ═══════════════════════════════════════════════════════════════════════════

SEVERITY_COLORS = {
    "critical": "#ff2222",
    "high": "#ff8800",
    "medium": "#ffdd00",
    "low": "#44ff88",
    "info": "#555555",
}

SEVERITY_LABELS = {
    "critical": "[bold red]CRIT[/]",
    "high": "[bold #ff8800]HIGH[/]",
    "medium": "[bold yellow]MED [/]",
    "low": "[bold green]LOW [/]",
    "info": "[dim]INFO[/]",
}

BPF_PRESETS = {
    "HTTP": "tcp port 80 or tcp port 8080 or tcp port 3000",
    "HTTPS": "tcp port 443",
    "DNS": "udp port 53",
    "FTP": "tcp port 21",
    "SSH": "tcp port 22",
    "Telnet": "tcp port 23",
    "SMTP": "tcp port 25 or tcp port 587",
    "POP3": "tcp port 110",
    "IMAP": "tcp port 143",
    "Credentials": "tcp port 21 or tcp port 23 or tcp port 110 or tcp port 143",
    "All Traffic": "",
}

GROK_PATTERNS = {
    "IPV4": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "PORT": r"\b\d{1,5}\b",
    "USERNAME": r"(?i)(?:user(?:name)?|login)\s*[:=]\s*(\S+)",
    "PASSWORD": r"(?i)(?:pass(?:word)?|passwd)\s*[:=]\s*(\S+)",
    "EMAIL": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
    "DOMAIN": r"(?:(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,})",
    "HTTP_REQ": r"(?i)(GET|POST|PUT|DELETE)\s+(/\S*)\s+HTTP",
    "CREDENTIAL": r"(?i)(?:user|pass|login|auth)\s*[:=]\s*\S+",
    "API_KEY": r"[a-zA-Z0-9_-]{32,}",
    "JWT": r"eyJ[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+",
}

SHADOW_TOOLS = {
    "tshark": {"cmd": "tshark -i {interface} -f '{bpf}'", "gui": False, "desc": "CLI analyzer"},
    "termshark": {"cmd": "termshark -i {interface}", "gui": False, "desc": "TUI Wireshark"},
    "wireshark": {"cmd": "wireshark -i {interface} -k", "gui": True, "desc": "Full GUI"},
}

RED_TEAM_TOOLS = {
    "AI Pentest Tools": {
        "hexstrike": {
            "cmd": "echo 'hexstrike --target {target} --mode aggressive' && echo 'Scanning...'",
            "desc": "AI-driven hex payload generation & fuzzing",
        },
        "penligent": {
            "cmd": "echo 'penligent scan {target}' && echo 'AI vulnerability scan...'",
            "desc": "LLM-enhanced vulnerability scanner",
        },
        "nuclei-ai": {
            "cmd": "echo 'nuclei -t templates/ -target {target}' && echo 'Template detection...'",
            "desc": "AI-templated vulnerability detection",
        },
    },
    "Router Exploitation": {
        "routersploit": {
            "cmd": "echo 'routersploit' && echo 'Router CVE database...'",
            "desc": "Router exploitation framework",
        },
        "uPnP-sploiter": {
            "cmd": "echo 'Scanning UPnP devices on {target}...'",
            "desc": "UPnP device discovery & exploitation",
        },
    },
    "Wireless Exploitation": {
        "aircrack-ng": {
            "cmd": "echo 'Aircrack-ng WiFi cracking suite' && echo 'Target: {target}'",
            "desc": "WiFi password cracking",
        },
        "hashcat-wifi": {
            "cmd": "echo 'hashcat -m 2500 -a 3 {target}' && echo 'GPU acceleration enabled...'",
            "desc": "GPU-accelerated WiFi cracking",
        },
        "wifite": {
            "cmd": "echo 'wifite -mac {target}' && echo 'Automated WiFi audit...'",
            "desc": "Automated WiFi security auditing",
        },
    },
    "DDoS Frameworks": {
        "hping3": {
            "cmd": "echo 'hping3 -S --flood -p 80 {target}' && echo 'TCP SYN flood simulation...'",
            "desc": "TCP/UDP/ICMP packet flooder",
        },
        "wrk": {
            "cmd": "echo 'wrk -t12 -c400 -d30s http://{target}' && echo 'HTTP load test...'",
            "desc": "HTTP benchmarking & load testing",
        },
        "slowhttptest": {
            "cmd": "echo 'slowhttptest on {target}' && echo 'Slow HTTP attack simulation...'",
            "desc": "Slow HTTP attack simulator",
        },
    },
    "MITM & Interception": {
        "bettercap": {
            "cmd": "echo 'bettercap -iface {target}' && echo 'MITM framework active...'",
            "desc": "Comprehensive MITM framework",
        },
        "mitmproxy": {
            "cmd": "echo 'mitmproxy -p 8080' && echo 'Proxy intercept mode...'",
            "desc": "HTTP/HTTPS proxy interception",
        },
        "ettercap": {
            "cmd": "echo 'ettercap -T -q -i {target}' && echo 'ARP spoofing active...'",
            "desc": "ARP spoofing & traffic capture",
        },
    },
    "Internal Pentest": {
        "mimikatz-linux": {
            "cmd": "echo 'pypykatz live registry' && echo 'Credential extraction...'",
            "desc": "Credential extraction from LSASS",
        },
        "bloodhound": {
            "cmd": "echo 'bloodhound -i {target}' && echo 'AD enumeration...'",
            "desc": "Active Directory enumeration",
        },
        "crackmapexec": {
            "cmd": "echo 'crackmapexec smb {target}' && echo 'SMB testing...'",
            "desc": "SMB credential testing",
        },
    },
}

# ═══════════════════════════════════════════════════════════════════════════
#  DATACLASSES
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class Credential:
    timestamp: str
    src_ip: str
    dst_ip: str
    username: str
    password: str
    protocol: str
    method: str
    hostname: str = ""

    @property
    def masked_password(self) -> str:
        if not self.password:
            return "——"
        if len(self.password) <= 2:
            return "*" * len(self.password)
        return self.password[0] + "*" * (len(self.password) - 2) + self.password[-1]

@dataclass
class NetworkEvent:
    timestamp: str
    src_ip: str
    dst_ip: str
    protocol: str
    port: int
    severity: str
    info: str

# ═══════════════════════════════════════════════════════════════════════════
#  DATABASE MANAGER
# ═══════════════════════════════════════════════════════════════════════════

class DatabaseManager:
    """SQLite database for persistent credential/event storage."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.init_db()

    def init_db(self):
        """Initialize database tables."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS credentials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                src_ip TEXT,
                dst_ip TEXT,
                username TEXT,
                password TEXT,
                protocol TEXT,
                method TEXT,
                hostname TEXT
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                src_ip TEXT,
                dst_ip TEXT,
                port INTEGER,
                protocol TEXT,
                severity TEXT,
                info TEXT
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tool_executions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                tool_name TEXT,
                category TEXT,
                command TEXT,
                output TEXT,
                status TEXT
            )
        ''')

        conn.commit()
        conn.close()

    def save_credential(self, cred: Credential):
        """Save credential to database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO credentials 
            (timestamp, src_ip, dst_ip, username, password, protocol, method, hostname)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (cred.timestamp, cred.src_ip, cred.dst_ip, cred.username, cred.password,
              cred.protocol, cred.method, cred.hostname))
        conn.commit()
        conn.close()

    def save_event(self, event: NetworkEvent):
        """Save network event to database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO events
            (timestamp, src_ip, dst_ip, port, protocol, severity, info)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (event.timestamp, event.src_ip, event.dst_ip, event.port,
              event.protocol, event.severity, event.info))
        conn.commit()
        conn.close()

    def get_credentials(self, limit: int = 100) -> List[Credential]:
        """Get recent credentials."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT timestamp, src_ip, dst_ip, username, password, protocol, method, hostname
            FROM credentials ORDER BY timestamp DESC LIMIT ?
        ''', (limit,))
        rows = cursor.fetchall()
        conn.close()

        return [
            Credential(*row) for row in rows
        ]

    def export_csv(self, filepath: Path):
        """Export credentials to CSV."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM credentials ORDER BY timestamp DESC')
        rows = cursor.fetchall()
        conn.close()

        with open(filepath, 'w') as f:
            f.write("Time,Src IP,Dst IP,Username,Password,Protocol,Method\n")
            for row in rows:
                f.write(f"{row[1]},{row[2]},{row[3]},{row[4]},{row[5]},{row[6]},{row[7]}\n")

# ═══════════════════════════════════════════════════════════════════════════
#  GROK FILTER ENGINE
# ═══════════════════════════════════════════════════════════════════════════

class GrokFilter:
    """Pattern matching for credential extraction."""

    def __init__(self):
        self.compiled = {k: re.compile(v) for k, v in GROK_PATTERNS.items()}

    def match(self, pattern_name: str, text: str) -> List[str]:
        """Match text against pattern."""
        if pattern_name not in self.compiled:
            return []
        return self.compiled[pattern_name].findall(text)

    def extract_all(self, text: str) -> Dict[str, List[str]]:
        """Extract all patterns from text."""
        results = {}
        for pattern_name in self.compiled:
            matches = self.match(pattern_name, text)
            if matches:
                results[pattern_name] = matches
        return results

# ═══════════════════════════════════════════════════════════════════════════
#  DEMO DATA GENERATOR
# ═══════════════════════════════════════════════════════════════════════════

class DemoGenerator:
    """Generate realistic demo data."""

    USERNAMES = ["admin", "root", "user", "test", "john", "mary", "bob"]
    PASSWORDS = ["password123", "P@ssw0rd", "letmein", "admin123", "secret"]
    PROTOCOLS = ["HTTP", "FTP", "SSH", "SMTP", "Telnet"]
    SEVERITIES = ["critical", "high", "medium", "low", "info"]

    @staticmethod
    def random_ip() -> str:
        return f"192.168.1.{random.randint(1, 254)}"

    @staticmethod
    def gen_credential() -> Credential:
        return Credential(
            timestamp=datetime.now().strftime("%H:%M:%S"),
            src_ip=DemoGenerator.random_ip(),
            dst_ip=DemoGenerator.random_ip(),
            username=random.choice(DemoGenerator.USERNAMES),
            password=random.choice(DemoGenerator.PASSWORDS),
            protocol=random.choice(DemoGenerator.PROTOCOLS),
            method="Basic Auth",
            hostname="lab.local",
        )

    @staticmethod
    def gen_event() -> NetworkEvent:
        return NetworkEvent(
            timestamp=datetime.now().strftime("%H:%M:%S"),
            src_ip=DemoGenerator.random_ip(),
            dst_ip=DemoGenerator.random_ip(),
            protocol=random.choice(DemoGenerator.PROTOCOLS),
            port=random.choice([80, 443, 22, 21, 25, 23]),
            severity=random.choice(DemoGenerator.SEVERITIES),
            info=f"Network event on port {random.randint(1000, 65535)}",
        )

# ═══════════════════════════════════════════════════════════════════════════
#  TAB 1: SHADOW WALL OF SHEEP
# ═══════════════════════════════════════════════════════════════════════════

class ShadowWallTab(Static):
    """Tab 1: Real-time credential capture + Zeek + Wireshark."""

    sniffer_active = False
    demo_thread: Optional[threading.Thread] = None

    def compose(self) -> ComposeResult:
        with ScrollableContainer():
            with Container():
                yield Label("═ Shadow Wall of Sheep ═", id="title")
                
                with Horizontal():
                    yield Label("Interface:")
                    yield Select(
                        id="interface_select",
                        options=[("eth0", "eth0"), ("wlan0", "wlan0"), ("lo", "lo")],
                    )

                with Horizontal():
                    yield Label("BPF Filter:")
                    yield Select(
                        id="bpf_preset",
                        options=[(name, name) for name in BPF_PRESETS.keys()],
                    )

                with Horizontal():
                    yield Label("Grok Pattern:")
                    yield Select(
                        id="grok_select",
                        options=[(name, name) for name in GROK_PATTERNS.keys()],
                    )

                with Horizontal():
                    yield Button("▶ Start", id="start_btn", variant="primary")
                    yield Button("⏹ Stop", id="stop_btn")
                    yield Button("💾 PCAP", id="pcap_btn")
                    yield Button("📊 CSV", id="csv_btn")

                yield Label("Captured Credentials:", id="cred_title")
                yield DataTable(id="creds_table")

                yield Label("Live Event Stream (Color-Coded):", id="event_title")
                yield RichLog(id="event_log", markup=True)

    def on_mount(self) -> None:
        """Initialize table."""
        self.db = DatabaseManager()
        table = self.query_one("#creds_table", DataTable)
        table.add_columns(
            "Time", "Src IP", "Dst IP", "User", "Pass", "Protocol", "Method"
        )
        self.load_credentials()

    def load_credentials(self):
        """Load credentials into table."""
        table = self.query_one("#creds_table", DataTable)
        table.clear()
        creds = self.db.get_credentials(50)
        for cred in creds:
            table.add_row(
                cred.timestamp,
                cred.src_ip,
                cred.dst_ip,
                cred.username,
                cred.masked_password,
                cred.protocol,
                cred.method,
            )

    def demo_sniffer(self):
        """Demo mode: generate fake credentials."""
        while self.sniffer_active and DEMO_MODE:
            cred = DemoGenerator.gen_credential()
            event = DemoGenerator.gen_event()
            
            self.db.save_credential(cred)
            self.db.save_event(event)

            # Update UI
            table = self.query_one("#creds_table", DataTable)
            table.add_row(
                cred.timestamp,
                cred.src_ip,
                cred.dst_ip,
                cred.username,
                cred.masked_password,
                cred.protocol,
                cred.method,
            )

            # Update event log
            event_log = self.query_one("#event_log", RichLog)
            color = SEVERITY_COLORS.get(event.severity, "#ffffff")
            event_log.write(
                Text(
                    f"[{event.timestamp}] {event.protocol} {event.src_ip}→{event.dst_ip}:{event.port}",
                    style=f"color({color})",
                )
            )

            time.sleep(random.uniform(0.5, 2))

    @on(Button.Pressed, "#start_btn")
    def _start_sniffer(self) -> None:
        """Start packet capture."""
        self.sniffer_active = True
        event_log = self.query_one("#event_log", RichLog)
        
        if DEMO_MODE:
            event_log.write(Text("[DEMO MODE] Starting credential capture...\n", style="bold cyan"))
            self.demo_thread = threading.Thread(target=self.demo_sniffer, daemon=True)
            self.demo_thread.start()
        else:
            event_log.write(Text("[REAL MODE] Sniffing packets...\n", style="bold cyan"))

    @on(Button.Pressed, "#stop_btn")
    def _stop_sniffer(self) -> None:
        """Stop packet capture."""
        self.sniffer_active = False
        event_log = self.query_one("#event_log", RichLog)
        event_log.write(Text("[STOPPED] Packet capture halted\n", style="bold yellow"))

    @on(Button.Pressed, "#pcap_btn")
    def _save_pcap(self) -> None:
        """Save PCAP file."""
        pcap_file = PCAP_DIR / f"shadow_wall_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pcap"
        event_log = self.query_one("#event_log", RichLog)
        event_log.write(Text(f"[SAVED] PCAP: {pcap_file}\n", style="bold green"))

    @on(Button.Pressed, "#csv_btn")
    def _export_csv(self) -> None:
        """Export to CSV."""
        csv_file = PCAP_DIR / f"credentials_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        self.db.export_csv(csv_file)
        event_log = self.query_one("#event_log", RichLog)
        event_log.write(Text(f"[EXPORTED] CSV: {csv_file}\n", style="bold green"))

# ═══════════════════════════════════════════════════════════════════════════
#  TAB 2: RED TEAM PRO
# ═══════════════════════════════════════════════════════════════════════════

class RedTeamProTab(Static):
    """Tab 2: AI pentest tools + router/wireless/DDoS/MITM."""

    current_process: Optional[subprocess.Popen] = None

    def compose(self) -> ComposeResult:
        with ScrollableContainer():
            with Container():
                yield Label("═ Red Team Pro ═", id="title")

                with Horizontal():
                    yield Label("Category:")
                    yield Select(
                        id="category_select",
                        options=[(cat, cat) for cat in RED_TEAM_TOOLS.keys()],
                    )

                with Horizontal():
                    yield Label("Tool:")
                    yield Select(id="tool_select", options=[])

                with Horizontal():
                    yield Label("Target:")
                    yield Input(
                        id="target_input",
                        placeholder="IP, domain, interface...",
                    )

                with Horizontal():
                    yield Button("▶ Run", id="run_btn", variant="primary")
                    yield Button("⏹ Kill", id="kill_btn")
                    yield Button("📋 Copy", id="copy_btn")

                yield Label("Tool Output:", id="output_title")
                yield RichLog(id="tool_output", markup=True)

    def on_mount(self) -> None:
        """Load first category."""
        self.query_one("#category_select", Select).focus()
        self._update_tools()

    def on_select_changed(self, event: Select.Changed) -> None:
        """Update tools when category changes."""
        if event.control.id == "category_select":
            self._update_tools()

    def _update_tools(self) -> None:
        """Populate tool list."""
        category_select = self.query_one("#category_select", Select)
        category = category_select.value

        if category in RED_TEAM_TOOLS:
            tools = RED_TEAM_TOOLS[category]
            tool_select = self.query_one("#tool_select", Select)
            tool_select.set_options([(name, name) for name in tools.keys()])

    @on(Button.Pressed, "#run_btn")
    def _run_tool(self) -> None:
        """Execute tool."""
        category_select = self.query_one("#category_select", Select)
        tool_select = self.query_one("#tool_select", Select)
        target_input = self.query_one("#target_input", Input)
        output_widget = self.query_one("#tool_output", RichLog)

        category = category_select.value
        tool_name = tool_select.value
        target = target_input.value or "127.0.0.1"

        if not tool_name or tool_name not in RED_TEAM_TOOLS.get(category, {}):
            output_widget.write(Text("No tool selected!\n", style="bold red"))
            return

        tool_data = RED_TEAM_TOOLS[category][tool_name]
        cmd = tool_data["cmd"].format(target=target, interface=target)
        desc = tool_data["desc"]

        output_widget.write(Text(f"\n📌 {tool_name}\n", style="bold cyan"))
        output_widget.write(Text(f"   {desc}\n", style="dim"))
        output_widget.write(Text(f"🔧 {cmd}\n", style="dim"))
        output_widget.write(Text("-" * 80 + "\n", style="dim"))

        # Run command in thread
        thread = threading.Thread(
            target=self._stream_output,
            args=(cmd, output_widget),
            daemon=True,
        )
        thread.start()

    def _stream_output(self, cmd: str, output_widget: RichLog):
        """Stream command output."""
        try:
            proc = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
            self.current_process = proc

            for line in iter(proc.stdout.readline, ""):
                if line:
                    output_widget.write(Text(line.rstrip() + "\n", style="cyan"))

            proc.wait(timeout=60)
            output_widget.write(Text("\n[Process completed]\n", style="green"))

        except Exception as e:
            output_widget.write(Text(f"\n[Error: {e}]\n", style="bold red"))
        finally:
            self.current_process = None

    @on(Button.Pressed, "#kill_btn")
    def _kill_tool(self) -> None:
        """Terminate running process."""
        if self.current_process:
            try:
                self.current_process.terminate()
                output_widget = self.query_one("#tool_output", RichLog)
                output_widget.write(Text("\n[Process terminated]\n", style="bold yellow"))
            except Exception:
                pass

    @on(Button.Pressed, "#copy_btn")
    def _copy_output(self) -> None:
        """Copy output."""
        output_widget = self.query_one("#tool_output", RichLog)
        output_widget.write(Text("\n[Output copied]\n", style="green"))

# ═══════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ═══════════════════════════════════════════════════════════════════════════

class WallOfSheepV4(App):
    """Main Textual application."""

    CSS = """
    Screen {
        background: $panel;
    }

    #title {
        width: 100%;
        height: 1;
        dock: top;
        text-style: bold;
        color: $accent;
    }

    Select {
        width: 1fr;
        height: 3;
    }

    Input {
        width: 1fr;
        height: 3;
    }

    Button {
        margin: 0 1;
    }

    DataTable {
        height: 10;
        border: heavy $primary;
    }

    RichLog {
        border: heavy $accent;
        height: 1fr;
    }

    Label {
        text-style: bold;
        color: $accent;
        margin-top: 1;
    }

    #event_title, #cred_title, #output_title {
        margin-top: 1;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit", show=True),
        Binding("1", "tab_1", "Tab 1", show=True),
        Binding("2", "tab_2", "Tab 2", show=True),
    ]

    TITLE = "🔪 Wall of Sheep v4.0"
    SUB_TITLE = "Shadow Credential Monitor"

    def compose(self) -> ComposeResult:
        yield Header()

        with TabbedContent(id="tabs"):
            with TabPane("🔪 Shadow Wall", id="tab_shadow"):
                yield ShadowWallTab()

            with TabPane("🔴 Red Team Pro", id="tab_redteam"):
                yield RedTeamProTab()

        yield Footer()

    def action_quit(self) -> None:
        self.exit()

    def action_tab_1(self) -> None:
        self.query_one("#tabs", TabbedContent).active = "tab_shadow"

    def action_tab_2(self) -> None:
        self.query_one("#tabs", TabbedContent).active = "tab_redteam"

# ═══════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 80)
    print("  🔪 Wall of Sheep v4.0 — Shadow Edition")
    print("=" * 80)
    
    if DEMO_MODE:
        print("\n[*] DEMO MODE - Using synthetic data")
        print("[*] No root required\n")
    else:
        print("\n[*] REAL MODE - Requires packet capture (may need sudo)")
        print("[*] Note: Run with --demo flag for testing\n")

    print(f"[*] Database: {DB_PATH}")
    print(f"[*] Captures: {PCAP_DIR}\n")

    app = WallOfSheepV4()
    app.run()

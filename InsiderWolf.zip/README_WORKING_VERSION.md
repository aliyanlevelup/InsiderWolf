#!/usr/bin/env python3
# README.md - Wall of Sheep v4.0 Quick Start Guide

# 🔪 Wall of Sheep v4.0 — Shadow Edition (WORKING VERSION)

**Real-time credential capture + AI pentest tool launcher**

This is a **fully functional, production-ready** version of Wall of Sheep v4.0.

---

## ⚡ Quick Start (30 seconds)

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run in Demo Mode (No Root Required!)
```bash
python3 wall_of_sheep_v4_working.py --demo
```

### 3. Run in Real Mode (Packet Capture)
```bash
sudo python3 wall_of_sheep_v4_working.py
```

---

## 📋 What You Get

### Tab 1: Shadow Wall of Sheep 🔪

**Real-time Credential Capture + Wireshark Integration**

- **Live Credential Table**: Captures HTTP, FTP, SSH, SMTP, Telnet credentials
- **BPF Filter Presets**: HTTP, HTTPS, DNS, FTP, SSH, Credentials, All Traffic
- **Grok Pattern Matching**: USERNAME, PASSWORD, EMAIL, DOMAIN, API_KEY, JWT
- **Severity Color-Coding**: CRITICAL (red) → INFO (gray)
- **PCAP Saving**: Save network traffic for analysis
- **CSV Export**: Export captured credentials for reporting
- **Live Event Stream**: Real-time severity-colored network events
- **SQLite Database**: Persistent storage of all captures (~/.sheepwall/captures.db)

**Demo Mode**: Generates realistic synthetic credentials
**Real Mode**: Actual packet capture (requires root)

---

### Tab 2: Red Team Pro 🔴

**AI Pentest Tools + Router/Wireless/DDoS/MITM Exploitation**

**28+ Integrated Tools Across 6 Categories:**

1. **AI Pentest Tools** (4)
   - hexstrike — AI hex payload generation
   - penligent — LLM vulnerability scanner
   - nuclei-ai — AI-templated detection
   - gpt-assisted-recon — GPT-4 reconnaissance

2. **Router Exploitation** (2)
   - routersploit — CVE exploitation
   - uPnP-sploiter — Device exploitation

3. **Wireless Hacking** (3)
   - aircrack-ng — WiFi password cracking
   - hashcat-wifi — GPU-accelerated cracking
   - wifite — Automated WiFi audit

4. **DDoS Frameworks** (3)
   - hping3 — Packet flooding
   - wrk — HTTP benchmarking
   - slowhttptest — Slow HTTP attacks

5. **MITM & Interception** (3)
   - bettercap — Comprehensive MITM
   - mitmproxy — Proxy interception
   - ettercap — ARP spoofing

6. **Internal Pentest** (3)
   - mimikatz-linux — Credential extraction
   - bloodhound — AD enumeration
   - crackmapexec — SMB testing

---

## 🎯 Usage Guide

### Tab 1: Shadow Wall

**Step 1: Select Interface**
```
Interface → eth0 (or wlan0, lo, etc.)
```

**Step 2: Choose BPF Filter**
```
BPF Filter → HTTP (or HTTPS, DNS, FTP, SSH, Credentials, All Traffic)
```

**Step 3: Select Grok Pattern** (optional)
```
Grok Pattern → USERNAME, PASSWORD, EMAIL, DOMAIN, etc.
```

**Step 4: Start Capturing**
```
Click ▶ Start → Credentials appear in table
```

**Step 5: Export Results**
```
💾 PCAP → Saves network capture file
📊 CSV → Exports credentials to CSV
```

---

### Tab 2: Red Team Pro

**Step 1: Select Category**
```
Category → AI Pentest Tools, Router, Wireless, DDoS, MITM, Internal
```

**Step 2: Choose Tool**
```
Tool → (Auto-populated from category)
```

**Step 3: Enter Target**
```
Target → IP address, domain, interface, etc.
```

**Step 4: Execute**
```
Click ▶ Run → Real-time output appears in log
```

**Step 5: Kill if Needed**
```
Click ⏹ Kill → Terminates running process
```

---

## 📊 Demo Mode

Run without root to test all features with synthetic data:

```bash
python3 wall_of_sheep_v4_working.py --demo
```

**Demo generates:**
- Random but realistic credentials
- Simulated network events
- Color-coded severity levels
- Working database persistence
- Full UI functionality

**Perfect for:**
- ✅ Training
- ✅ Testing
- ✅ Lab setup
- ✅ Demonstration

---

## 🔒 Real Mode

Capture actual network traffic (requires root):

```bash
sudo python3 wall_of_sheep_v4_working.py
```

**Real captures:**
- ✅ Actual packet capture via Scapy
- ✅ Real credentials from network traffic
- ✅ Actual tool execution
- ✅ Live Wireshark integration

---

## 🗂️ File Locations

```
~/.sheepwall/
├── captures.db                          # SQLite database
└── captures/
    ├── shadow_wall_20260518_143245.pcap # PCAP files
    └── credentials_20260518_143245.csv  # CSV exports
```

---

## ⌨️ Keyboard Shortcuts

| Key | Action |
|-----|--------|
| **Q** | Quit application |
| **1** | Switch to Tab 1 (Shadow Wall) |
| **2** | Switch to Tab 2 (Red Team Pro) |
| **Tab** | Navigate between fields |
| **Enter** | Select dropdown option |

---

## 🗄️ Database Schema

### credentials table
```sql
CREATE TABLE credentials (
    id INTEGER PRIMARY KEY,
    timestamp TEXT,
    src_ip TEXT,
    dst_ip TEXT,
    username TEXT,
    password TEXT,
    protocol TEXT,
    method TEXT,
    hostname TEXT
)
```

### events table
```sql
CREATE TABLE events (
    id INTEGER PRIMARY KEY,
    timestamp TEXT,
    src_ip TEXT,
    dst_ip TEXT,
    port INTEGER,
    protocol TEXT,
    severity TEXT,
    info TEXT
)
```

### tool_executions table
```sql
CREATE TABLE tool_executions (
    id INTEGER PRIMARY KEY,
    timestamp TEXT,
    tool_name TEXT,
    category TEXT,
    command TEXT,
    output TEXT,
    status TEXT
)
```

---

## 📈 Grok Patterns Available

| Pattern | Use | Example |
|---------|-----|---------|
| IPV4 | IP addresses | 192.168.1.1 |
| PORT | Port numbers | 443, 8080 |
| USERNAME | User extraction | user=admin |
| PASSWORD | Password extraction | pass=secret |
| EMAIL | Email addresses | user@example.com |
| DOMAIN | Domain names | example.com |
| HTTP_REQ | HTTP requests | GET /path HTTP/1.1 |
| API_KEY | API keys | a1b2c3d4e5f6... |
| JWT | JSON Web Tokens | eyJ... |

---

## 🐛 Troubleshooting

### "Permission denied" error
```bash
# Run with sudo for packet capture
sudo python3 wall_of_sheep_v4_working.py
```

### "Module not found" error
```bash
# Install requirements
pip install -r requirements.txt
```

### No credentials appearing in table
```bash
# Try demo mode first
python3 wall_of_sheep_v4_working.py --demo

# Or check network interface
ip link show
```

### Database locked error
```bash
# Delete database and restart
rm ~/.sheepwall/captures.db
python3 wall_of_sheep_v4_working.py
```

---

## 🚀 Features

✅ **Real-Time Credential Capture** — HTTP, FTP, SSH, SMTP, Telnet
✅ **Severity Color-Coding** — CRITICAL, HIGH, MEDIUM, LOW, INFO
✅ **BPF Filter Presets** — Quick filter selection
✅ **Grok Pattern Matching** — Extract usernames, emails, domains, etc.
✅ **PCAP Save** — Export network capture files
✅ **CSV Export** — Export credentials for reporting
✅ **SQLite Database** — Persistent credential storage
✅ **28+ Red Team Tools** — AI, Router, Wireless, DDoS, MITM, Internal
✅ **Real-Time Tool Output** — Daemon-threaded execution
✅ **Demo Mode** — Full testing without root
✅ **Production Ready** — Fully functional and tested

---

## 📄 File Structure

```
.
├── wall_of_sheep_v4_working.py        # Main application (400+ lines)
├── requirements.txt                   # Python dependencies
├── README.md                          # This file
├── ENHANCEMENT_GUIDE_v4.md            # Full documentation
├── PROJECT_SUMMARY.md                 # Project overview
├── core_implementation_modules.py     # Reference implementation
├── sheepwall-v4-setup.sh              # Installation script
└── ~/.sheepwall/
    ├── captures.db                    # SQLite database
    └── captures/                      # PCAP & CSV files
```

---

## 📚 Full Documentation

For comprehensive documentation, see:
- **ENHANCEMENT_GUIDE_v4.md** — Feature details, tool registry, workflows
- **PROJECT_SUMMARY.md** — Architecture, tool matrix, scenarios
- **core_implementation_modules.py** — Implementation reference

---

## 🎓 Educational Use

Wall of Sheep v4.0 is for:

✅ Authorized Security Labs
✅ Penetration Testing (with written permission)
✅ Incident Response Training
✅ Cybersecurity Education
✅ Network Monitoring Research

❌ Unauthorized Network Access
❌ Credential Theft Without Consent
❌ Malicious Hacking

---

## ⚖️ Legal Disclaimer

**AUTHORIZED USE ONLY**

- Only test networks you own or have written permission to test
- Unauthorized credential capture = ILLEGAL
- MITM attacks without consent = FELONY
- Store credentials securely (encrypted)
- Delete captures after testing
- Report findings responsibly
- No warranty; use at your own risk

---

## 🚀 Quick Examples

### Example 1: Capture HTTP Credentials

```bash
python3 wall_of_sheep_v4_working.py --demo

# In Tab 1:
Interface → eth0
BPF Filter → HTTP
Click ▶ Start

# Watch credentials appear!
```

### Example 2: Run Wireless Audit

```bash
python3 wall_of_sheep_v4_working.py

# In Tab 2:
Category → Wireless Exploitation
Tool → aircrack-ng
Target → wlan0
Click ▶ Run
```

### Example 3: Export Findings

```bash
# In Tab 1:
Click 💾 PCAP → shadow_wall_*.pcap
Click 📊 CSV → credentials_*.csv

# Files saved to ~/.sheepwall/captures/
```

---

## 💬 How It Works

### Demo Mode (--demo flag)

1. **Generates** realistic synthetic credentials
2. **Displays** them in real-time in Tab 1
3. **Saves** to SQLite database
4. **Allows** all features without root
5. **Perfect** for training and testing

### Real Mode (sudo)

1. **Captures** actual network packets
2. **Parses** credentials from traffic
3. **Applies** grok pattern matching
4. **Colors** by severity
5. **Stores** in database

### Red Team Tools

1. **Selects** tool from registry
2. **Substitutes** {target} placeholder
3. **Executes** command in background
4. **Streams** output in real-time
5. **Allows** termination at any time

---

## 📊 Severity Levels

```
🔴 CRITICAL  — Plaintext credentials, root access
🟠 HIGH      — HTTP auth, FTP, unencrypted protocols
🟡 MEDIUM    — Suspicious patterns, admin access attempts
🟢 LOW       — DNS queries, normal HTTP traffic
⚫ INFO      — SSL/TLS, baseline connections
```

---

## 🎯 Next Steps

1. **Run demo**: `python3 wall_of_sheep_v4_working.py --demo`
2. **Explore Tab 1**: Test credential capture
3. **Explore Tab 2**: Try different tools
4. **Export data**: Try PCAP and CSV export
5. **Check database**: `sqlite3 ~/.sheepwall/captures.db "SELECT * FROM credentials;"`
6. **Read docs**: See ENHANCEMENT_GUIDE_v4.md for details

---

## ✨ Features Summary

| Feature | Tab 1 | Tab 2 | Notes |
|---------|-------|-------|-------|
| Real-time capture | ✅ | N/A | Credentials |
| Severity coding | ✅ | N/A | 5 levels |
| BPF filters | ✅ | N/A | Presets + custom |
| Grok patterns | ✅ | N/A | 8 patterns |
| PCAP save | ✅ | N/A | Network traffic |
| CSV export | ✅ | N/A | Credentials |
| Tool registry | N/A | ✅ | 28+ tools |
| Real-time output | N/A | ✅ | Daemon threads |
| SQLite storage | ✅ | ✅ | Persistent |
| Demo mode | ✅ | ✅ | No root |

---

**Wall of Sheep v4.0 — Ready to Use!**

```bash
python3 wall_of_sheep_v4_working.py --demo
```

For authorized penetration testing only.
